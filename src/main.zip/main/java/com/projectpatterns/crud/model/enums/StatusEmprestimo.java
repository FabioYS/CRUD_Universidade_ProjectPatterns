package com.projectpatterns.crud.model.enums;

public enum StatusEmprestimo {
    PENDENTE,
    EM_ANDAMENTO,
    ATRASADO,
    CONCLUIDO,
    CANCELADO
}
