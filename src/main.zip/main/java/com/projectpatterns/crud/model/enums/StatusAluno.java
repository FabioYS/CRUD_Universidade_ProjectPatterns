package com.projectpatterns.crud.model.enums;

public enum StatusAluno {
    ATIVO,
    INATIVO,
    SUSPENSO,
    TRANSFERIDO,
    FORMADO
}
