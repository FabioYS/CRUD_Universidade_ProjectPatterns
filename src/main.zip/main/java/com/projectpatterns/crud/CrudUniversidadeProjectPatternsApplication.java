package com.prokectpatterns.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudUniversidadeProjectPatternsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudUniversidadeProjectPatternsApplication.class, args);
	}

}
